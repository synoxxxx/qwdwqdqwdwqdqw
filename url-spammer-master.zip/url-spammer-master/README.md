**Novasy Url Spammer**

Selam, bahsedilecek pek bir şey yok <a href="https://github.com/novasy/novasy-url-spam/blob/master/config.json" target="_blank">config.json</a> dosyasını düzenledikten sonra kullanabilirsiniz.


**Bana ulaşabileceğiniz sosyal medya hesaplarım:**

 [![](https://cdn.discordapp.com/attachments/806690258086658090/823829343499321384/68747470733a2f2f696d672e736869656c64732e696f2f62616467652f646973636f72642532302d3732383944412e737667.png)](https://discord.com/users/729226812776906832) [![](https://cdn.discordapp.com/attachments/806690258086658090/823829296912269364/68747470733a2f2f696d672e736869656c64732e696f2f62616467652f4769744875622532302d3139313731372e7376673f.png)](https://github.com/novasy) [![](https://cdn.discordapp.com/attachments/806690258086658090/823829272291573760/68747470733a2f2f696d672e736869656c64732e696f2f62616467652f494e5354414752414d2532302d4443333137352e73.png)](https://www.instagram.com/novasyy/)
